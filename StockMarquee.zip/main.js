var stockList = $("#stock-list");
var stockinfo_url = "http://ecc23880113.ddns.net/stockinfo/"

$(document).ready(function () {
  ("use strict");

  makeStockList();
  // updateStocks()
  stockList.marquee({ duration: 5000 });
  $(".test").marquee({ duration: 5000 });

  updateStocks()
  setInterval(updateStocks, 20000)
});

function insertStock(e) {
  var ele = `
    <div class="stock" data-stock="${e.code}">
      <div class="stock-code">${e.code}</div>
      <div class="stock-name">${e.name}</div>
      <div class="stock-price">${e.price}</div>
      <div class="stock-updn triangle-none"></div>
      <div class="stock-change price-none">${e.change}</div>
    </div>
    `;
  stockList.append(ele);
}

function updateStocks() {
  BLUE_CHIPS.forEach(e => {
    updateStock(e.code)
  })
}

function updateStock(stockCode) {
  // get stock values
  fetch(stockinfo_url + stockCode)
    .then(res => res.json())
    .then(data => {
      // find the stock in html and assign values
      stock = $("div").find(`[data-stock='${stockCode}']`)
      updn = stock.find(".stock-updn")
      price = stock.find(".stock-price").html(data.price);
      change = stock.find(".stock-change").html(data.change);

      updn.removeClass("triangle-up triangle-down triangle-none")
      change.removeClass("price-up price-down price-none")
      if (data.updn == "up") {
        updn.addClass("triangle-up")
        change.addClass("price-up")
      }
      else if (data.updn == "down") {
        updn.addClass("triangle-down")
        change.addClass("price-down")
      }
      else {
        updn.addClass("triangle-none")
        change.addClass("price-none")
      }
    })
}

function makeStockList() {
  // clear values
  BLUE_CHIPS.forEach((e) => {
    e.change = 0
    e.updn = "no"
    insertStock(e);
  })
}



