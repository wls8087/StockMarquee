
#### 藍籌股 [url](http://content.etnet.com.hk/content/sywg/tc/securities_index.php?subtype=HSI)

    http://content.etnet.com.hk/content/sywg/tc/securities_index.php?subtype=HSI


#### 個別股票 [url](http://www.etnet.com.hk/www/tc/stocks/realtime/quote.php?code=5)
    http://www.etnet.com.hk/www/tc/stocks/realtime/quote.php?code=5


#### html
    <div id="stock-list">  
      <div class="stock green">
        <div class="stock-code">0005</div>
        <div class="stock-name">匯豐控股</div>
        <div class="stock-price">54.10</div>
        <div class="trangle-up"></div>
        <div class="stock-change">0.60</div>
      </div>
      <div class="stock blue">
        <div class="stock-code">0011</div>
        <div class="stock-name">恆生銀行</div>
        <div class="stock-price">152.60</div>
        <div class="trangle-none"></div>
        <div class="stock-change">0.00</div>
      </div>
      <div class="stock red">
        <div class="stock-code">0941</div>
        <div class="stock-name">中國移動</div>
        <div class="stock-price">54.70</div>
        <div class="trangle-down"></div>
        <div class="stock-change">6.00</div>
      </div>
    </div>